#ifndef __XMSEVENTHANDLE_H__
#define __XMSEVENTHANDLE_H__

#include "DJAcsAPIDef.h"
#include "DJAcsDevState.h"

// XMS main event handler
DJ_Void XMSEventHandler(DJ_U32 u32EsrParam);

#endif

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XMSVoIPDemo.rc
//
#define IDD_XMSVOIPDEMO_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDD_RTPSESSION_DIALOG           131
#define IDD_DIALOG_TRANSFER             133
#define IDC_LIST_IP                     1000
#define IDC_LIST_VOICE                  1001
#define IDC_BUTTON_MAKECALL             1002
#define IDC_EDIT_CALLEE_ADDR            1003
#define IDC_EDIT_CALLEE_PORT            1004
#define IDC_EDIT_CALLEE_USERID          1005
#define IDC_EDIT_CALLEE_TELNO           1006
#define IDC_EDIT_CALLEE_PSW             1007
#define IDC_EDIT_DEST_SLOT              1007
#define IDC_BUTTON_REG                  1008
#define IDC_BUTTON_UNREG                1009
#define IDC_EDIT_CALLER_TELNO           1010
#define IDC_BUTTON_BIND                 1011
#define IDC_BUTTON_ANSWERCALL           1012
#define IDC_BUTTON_DROPCALL             1013
#define IDC_RADIO_H323                  1014
#define IDC_RADIO_SIP                   1015
#define IDC_EDIT_SERVER_ADDR            1016
#define IDC_EDIT_SERVER_PORT            1017
#define IDC_BUTTON_INIT                 1018
#define IDC_BUTTON_OPEN_IP              1019
#define IDC_BUTTON_OPENALL_IP           1020
#define IDC_EDIT_PLAYFILE               1021
#define IDC_BUTTON_BROWSEPLAYFILE       1022
#define IDC_RADIO_8K                    1023
#define IDC_RADIO_6K                    1024
#define IDC_RADIO_ALAW                  1025
#define IDC_RADIO_ULAW                  1026
#define IDC_BUTTON_PLAY                 1027
#define IDC_BUTTON_CLOSE_IP             1028
#define IDC_BUTTON_CLOSEALL_IP          1029
#define IDC_BUTTON_UNBIND               1030
#define IDC_BUTTON_OPEN_VOC             1031
#define IDC_BUTTON_CLOSE_VOC            1032
#define IDC_BUTTON_OPENALL_VOC          1033
#define IDC_BUTTON_CLOSEALL_VOC         1034
#define IDC_EDIT_RECORDFILE             1035
#define IDC_BUTTON_BROWSERECORDFILE     1036
#define IDC_BUTTON_RECORD               1037
#define IDC_BUTTON_DTMF1                1038
#define IDC_RADIO_H245UII               1039
#define IDC_BUTTON_DTMF2                1040
#define IDC_RADIO_RTP2833               1041
#define IDC_RADIO_SIPINFO               1042
#define IDC_BUTTON_OPEN_CONF            1043
#define IDC_BUTTON_JOIN_CONF            1044
#define IDC_BUTTON_3PCONF               1045
#define IDC_BUTTON_DTMF3                1046
#define IDC_BUTTON_DTMF4                1047
#define IDC_BUTTON_DTMF5                1048
#define IDC_BUTTON_DTMF6                1049
#define IDC_BUTTON_DTMF7                1050
#define IDC_BUTTON_DTMF8                1051
#define IDC_BUTTON_DTMF9                1052
#define IDC_BUTTON_DTMF0                1053
#define IDC_BUTTON_DTMFA                1054
#define IDC_BUTTON_DTMFP                1055
#define IDC_TREE_CONF                   1056
#define IDC_BUTTON_CLOSE_CONF           1057
#define IDC_BUTTON_LEAVE_CONF           1058
#define IDC_BUTTON_CLEAR_CONF           1059
#define IDC_EDIT_USERNAME               1060
#define IDC_EDIT_PASSWORD               1061
#define IDC_EDIT_DSPID                  1062
#define IDC_EDIT_AUDIO_IP               1063
#define IDC_EDIT_CALLEE_ADDR2           1063
#define IDC_EDIT_AUDIO_PORT             1064
#define IDC_EDIT_CALLEE_PORT2           1064
#define IDC_RADIO_AUDIO_ENABLE          1065
#define IDC_EDIT_CALLEE_USERID2         1065
#define IDC_RADIO_AUDIO_DISABLE         1066
#define IDC_BUTTON_TRANSFERCALL         1066
#define IDC_COMBO_AUDIO_CODECTX         1067
#define IDC_COMBO_AUDIO_CODECRX         1068
#define IDC_BUTTON_CHAIRMAN             1069
#define IDC_EDIT_AUDIO_PTTX             1070
#define IDC_EDIT_AUDIO_PTRX             1071
#define IDC_EDIT_VIDEO_PTTX             1072
#define IDC_EDIT_VIDEO_PTRX             1073
#define ID_BTN_OK                       1074
#define IDC_RADIO_VIDEO_ENABLE          1075
#define IDC_USE_PROXY                   1075
#define IDC_RADIO_VIDEO_DISABLE         1076
#define IDC_COMBO_URI                   1076
#define IDC_EDIT_VIDEO_IP               1077
#define IDC_EDIT_VIDEO_PORT             1078
#define IDC_COMBO_VIDEO_CODECTX         1079
#define IDC_COMBO_VIDEO_CODECRX         1080

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1077
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
